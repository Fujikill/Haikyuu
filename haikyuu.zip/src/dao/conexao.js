const { Pool } = require('pg');

const pool = new Pool({
    user: 'Henrique',
    host: 'localhost',
    database: 'post1',
    password: '1234',
    port: 5432
})

module.exports = pool;